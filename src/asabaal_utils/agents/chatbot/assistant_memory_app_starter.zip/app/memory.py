import json, os, uuid, time
from datetime import datetime
from typing import List, Dict, Tuple
from .schemas import MemoryItem, MemoryCreate, MemoryUpdate, UsedMemory

DATA_FILE = os.environ.get("MEMORY_JSON_PATH", os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "memory.json"))

def _now() -> datetime:
    return datetime.utcnow()

def _load() -> List[MemoryItem]:
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        raw = json.load(f)
    return [MemoryItem(**x) for x in raw]

def _save(items: List[MemoryItem]) -> None:
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump([x.model_dump(mode="json") for x in items], f, ensure_ascii=False, indent=2, default=str)

def list_items(query: str = "", tags: List[str] = None, status: str = "active", limit: int = 50) -> List[MemoryItem]:
    items = _load()
    if status:
        items = [i for i in items if i.status == status]
    if tags:
        items = [i for i in items if set(tags).issubset(set(i.tags))]
    if query:
        q = query.lower()
        items = [i for i in items if q in i.title.lower() or q in i.content.lower()]
    return items[:limit]

def create_item(payload: MemoryCreate) -> MemoryItem:
    items = _load()
    new = MemoryItem(
        id=str(uuid.uuid4()),
        title=payload.title.strip(),
        content=payload.content.strip(),
        tags=payload.tags or [],
        status="active",
        created_at=_now(),
        updated_at=_now(),
        provenance={"source_type": "manual"}
    )
    items.append(new)
    _save(items)
    return new

def get_item(item_id: str) -> MemoryItem | None:
    for i in _load():
        if i.id == item_id:
            return i
    return None

def update_item(item_id: str, patch: MemoryUpdate) -> MemoryItem | None:
    items = _load()
    found = None
    for idx, it in enumerate(items):
        if it.id == item_id:
            data = it.model_dump()
            if patch.title is not None:
                data["title"] = patch.title
            if patch.content is not None:
                data["content"] = patch.content
            if patch.tags is not None:
                data["tags"] = patch.tags
            if patch.status is not None:
                data["status"] = patch.status
            data["updated_at"] = _now()
            found = MemoryItem(**data)
            items[idx] = found
            break
    if found:
        _save(items)
    return found

def delete_item(item_id: str) -> bool:
    items = _load()
    n_before = len(items)
    items = [i for i in items if i.id != item_id]
    _save(items)
    return len(items) < n_before

def stub_retrieval(user_query: str, top_k: int = 5) -> List[UsedMemory]:
    """Very simple keyword-scoring to simulate retrieval.
    Replace this with Cognee search (vector + graph) in production.
    """
    items = _load()
    q = user_query.lower()
    scored: List[Tuple[MemoryItem, float]] = []
    for it in items:
        score = 0.0
        if q in it.title.lower():
            score += 0.7
        if q in it.content.lower():
            score += 0.6
        # tag bonus for exact token matches
        for t in it.tags:
            if t.lower() in q.split():
                score += 0.1
        if score > 0:
            scored.append((it, min(score, 1.0)))
    scored.sort(key=lambda x: x[1], reverse=True)
    return [UsedMemory(id=it.id, title=it.title, score=score) for it, score in scored[:top_k]]
